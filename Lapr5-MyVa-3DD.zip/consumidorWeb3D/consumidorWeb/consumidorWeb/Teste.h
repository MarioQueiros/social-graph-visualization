#pragma once


using namespace std;

class Teste
{
public:
	Teste(void);
	virtual ~Teste(void);
	string pedido();
};


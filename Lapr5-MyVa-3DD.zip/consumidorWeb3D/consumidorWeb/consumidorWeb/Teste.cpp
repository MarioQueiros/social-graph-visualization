#include "Teste.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <iostream>

using namespace std;

Teste::Teste(void)
{
}


Teste::~Teste(void)
{
}

string pedido(){

}

void main(int argc, char **argv)
{
	string s =pedido();
	printf(s);
}